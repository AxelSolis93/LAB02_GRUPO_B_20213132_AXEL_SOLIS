#include <iostream> //Axel Jhuan Solis Zamata
#include <memory>

using namespace std;

class C1
{
private:
std::shared_ptr<double> d;
public:
C1(std::weak_ptr<double> value) : d(value) {} //weak pointer
virtual ~C1() { cout << "\nC1 destructor\n"; }
void print() const { cout << "Valor " << *d; }
};

class C2
{
private:
std::shared_ptr<double> d;
public:
C2(std::weak_ptr<double> value) : d(value) {}
virtual ~C2() { cout << "\nC2 destructor\n"; }
void print() const { cout << "Valor " << *d; }
};
int main(){
	std::shared_ptr<double> x{new double(10.0)};
	std::shared_ptr<C1> A{new C1(x)};
	std::shared_ptr<C2> B{new C2(x)};
	A->print();
	cout<<endl;
	B->print();

}