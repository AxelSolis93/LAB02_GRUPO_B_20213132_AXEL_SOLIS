#include <iostream> //Axel Jhuan Solis Zamata
#include <memory>

class Point
{
public:
Point(double x, double y) : x(x), y(y) {};
void print()
{
std::cout << "(" << x << ", " << y << ")\n";
}
void X(double x){
	this->x = x;
}
void Y(double y){
	this->y = y;
}
private:
double x{}, y{};
};

main(){
std::shared_ptr<double> d(new double(1.0));
std::shared_ptr<Point> pt (new Point(1.0,2.0));
*d = 2.0; //el valor del puntero d ahora es igual a 2
(*pt).X(3.0); //Cambia el valor de x a 3
(*pt).Y(3.0); //Cambia el valor de y a 3
pt->X(3.0);
pt->Y(3.0);
(*pt).print();
pt->print();
std::cout <<*d;
}