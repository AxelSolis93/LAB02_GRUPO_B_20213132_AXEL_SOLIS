#pragma once
#include <iostream> //Axel Jhuan Solis Zamata
#include "ClaseMultimedia.h"
#include <string>
using namespace std;
class DerivadaDiscos:public ClaseMultimedia{
	private:
		int year;
		string titulo;
		string cantante;
		string genero;
	public:
		DerivadaDiscos(int, string, string, string);
		~DerivadaDiscos();
		void MetodoDiscos();
};
