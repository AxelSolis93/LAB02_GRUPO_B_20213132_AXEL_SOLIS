#include "stdafx.h"
#include <iostream> //Axel Jhuan Solis Zamata
#include "DerivadaDisco.h"
#include <string>
using namespace std;
int main(){
	string titulo,cantante,genero;
	int year{0};
	cout << "Ingrese el titulo: " << endl;
	getline(cin,titulo);
	cout << "Ingrese el cantante: " << endl;
	getline(cin,cantante);
	cout << "Ingrese el genero: " << endl;
	getline(cin,genero);
	cout << "Ingrese el año: " << endl;
	cin>>year;
	DerivadaDiscos obj1 = DerivadaDiscos(year, titulo,cantante,genero);
	obj1.MetodoDiscos();
	obj1.MetodoMultimedia();
	system("pause");
}
