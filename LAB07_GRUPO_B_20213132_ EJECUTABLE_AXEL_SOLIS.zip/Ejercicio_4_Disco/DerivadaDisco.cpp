#include "stdafx.h"
#include <iostream> //Axel Jhuan Solis Zamata
#include "DerivadaDisco.h"
#include <string>
using namespace std;
DerivadaDiscos::DerivadaDiscos(int _year, string _titulo, string _cantante, string _genero){
	year = _year;
	titulo = _titulo;
	cantante = _cantante;
	genero = _genero;
}
DerivadaDiscos::~DerivadaDiscos(){
}
void DerivadaDiscos::MetodoDiscos(){
	cout << "Disco: " << titulo << endl;
	cout << "Cantante: " << cantante << endl;
	cout << "Genero: " << genero << endl;
	cout << "Año de publicacion: " << year << endl; 
}

