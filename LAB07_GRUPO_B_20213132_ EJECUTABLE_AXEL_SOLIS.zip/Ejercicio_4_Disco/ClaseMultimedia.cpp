#include "stdafx.h"
#include <iostream> //Axel Jhuan Solis Zamata
#include "ClaseMultimedia.h"
#include <string>
using namespace std;
ClaseMultimedia::ClaseMultimedia()
{
}
ClaseMultimedia::~ClaseMultimedia()
{
}
void ClaseMultimedia::MetodoMultimedia(){;
	
}

