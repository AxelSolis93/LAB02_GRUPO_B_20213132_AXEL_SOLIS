#pragma once
#include <iostream> //Axel Jhuan Solis Zamata
#include <string>
using namespace std;
class ClaseMultimedia{
	protected:
		int year;
		string titulo;
		string cantante;
	public:
		ClaseMultimedia();
		~ClaseMultimedia();
		void MetodoMultimedia();
};
