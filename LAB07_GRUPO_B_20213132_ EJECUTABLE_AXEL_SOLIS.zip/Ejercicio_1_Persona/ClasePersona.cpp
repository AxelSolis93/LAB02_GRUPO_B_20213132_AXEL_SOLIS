#include "stdafx.h"
#include <iostream> //Axel Jhuan Solis Zamata
#include "ClasePersona.h"
#include <string>
using namespace std;
ClasePersona::ClasePersona()
{
}
ClasePersona::~ClasePersona()
{
}
void ClasePersona::MetodoPersona(){;
	
}

