#pragma once
#include <iostream> //Axel Jhuan Solis Zamata
#include <string>
using namespace std;
class ClasePersona{
	protected:
		int edad;
		string nombre;
	public:
		ClasePersona();
		~ClasePersona();
		void MetodoPersona();
};
