#pragma once
#include <iostream> //Axel Jhuan Solis Zamata
#include "ClasePersona.h"
#include <string>
using namespace std;
class PersonaDerivada:public ClasePersona{
	private:
		string nombre;
		int edad;
	public:
		PersonaDerivada(string,int);
		~PersonaDerivada();
		void MetodoPersonaDerivada();
};
