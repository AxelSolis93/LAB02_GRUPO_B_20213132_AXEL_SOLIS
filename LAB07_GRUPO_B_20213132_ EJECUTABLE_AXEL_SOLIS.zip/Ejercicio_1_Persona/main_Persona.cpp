#include "stdafx.h"
#include <iostream> //Axel Jhuan Solis Zamata
#include "DerivadaAlumno.h"
#include <string>
int main(){
	string nombre;
	int edad{0};
	cout << "Ingrese el nombre de la persona: " << endl;
	cin>>nombre;
	cout << "Ingrese la edad de la persona: " << endl;
	cin>>edad;
	PersonaDerivada obj1 = PersonaDerivada(nombre, edad);
	obj1.MetodoPersonaDerivada();
	obj1.MetodoPersona();
	system("pause");
}
