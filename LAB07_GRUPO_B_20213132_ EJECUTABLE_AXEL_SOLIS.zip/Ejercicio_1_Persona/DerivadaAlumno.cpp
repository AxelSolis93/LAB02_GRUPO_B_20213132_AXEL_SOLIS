#include "stdafx.h"
#include <iostream> //Axel Jhuan Solis Zamata
#include "DerivadaAlumno.h"
#include <string>
using namespace std;
PersonaDerivada::PersonaDerivada(string _nombre, int _edad){
	nombre = _nombre;
	edad = _edad;
}
PersonaDerivada::~PersonaDerivada(){
}
void PersonaDerivada::MetodoPersonaDerivada(){
	cout << "El nombre del alumno es " << nombre << " y su edad es " << edad << endl;
}

