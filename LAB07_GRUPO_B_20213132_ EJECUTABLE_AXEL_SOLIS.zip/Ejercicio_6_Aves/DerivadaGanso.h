#pragma once
#include <iostream> //Axel Jhuan Solis Zamata
#include "ClaseAve.h"
#include <string>
using namespace std;
class DerivadaGanso:public ClaseAve{
	private:
		bool vertebrado;
		bool oviparo;
		bool pico;
		bool vuela;
	public:
		DerivadaGanso(bool, bool, bool, bool);
		~DerivadaGanso();
		void MetodoGanso();
};
