#include "stdafx.h"
#include <iostream> //Axel Jhuan Solis Zamata
#include "DerivadaGallina.h"
#include <string>
using namespace std;
DerivadaGallina::DerivadaGallina(bool _vertebrado, bool _oviparo, bool _pico, bool _vuela){
	vertebrado = _vertebrado;
	oviparo = _oviparo;
	pico = _pico;
	vuela = _vuela;
}
DerivadaGallina::~DerivadaGallina(){
}
void DerivadaGallina::MetodoGallina(){
	cout << "La gallina es un animal ";
	if(vertebrado==true){
		cout << "vertebrado, ";
	}else{
		cout << "invertebrado, ";
	}if(oviparo==true){
		cout << "oviparo, ";
	}else{
		cout<< "no oviparo, ";
	}if(pico==true){
		cout<< "tiene pico y ";
	}else{
		cout << "no tiene pico y ";
	}if(vuela==true){
		cout << "vuela."<<endl;
	}else{
		cout << "no vuela."<<endl;
	}
}

