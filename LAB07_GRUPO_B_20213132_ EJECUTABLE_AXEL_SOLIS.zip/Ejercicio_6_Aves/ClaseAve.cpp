#include "stdafx.h"
#include <iostream> //Axel Jhuan Solis Zamata
#include "ClaseAve.h"
#include <string>
using namespace std;
ClaseAve::ClaseAve()
{
}
ClaseAve::~ClaseAve()
{
}
void ClaseAve::MetodoAve(){
}

