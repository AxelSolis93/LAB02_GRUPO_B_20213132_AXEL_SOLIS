#include "stdafx.h"
#include <iostream> //Axel Jhuan Solis Zamata
#include "DerivadaGanso.h"
#include <string>
using namespace std;
DerivadaGanso::DerivadaGanso(bool _vertebrado, bool _oviparo, bool _pico, bool _vuela){
	vertebrado = _vertebrado;
	oviparo = _oviparo;
	pico = _pico;
	vuela = _vuela;
}
DerivadaGanso::~DerivadaGanso(){
}
void DerivadaGanso::MetodoGanso(){
	cout << "El ganso es ";
	if(vertebrado==true){
		cout << "vertebrado, ";
	}else if(vertebrado==false){
		cout << "invertebrado, ";
	}if(oviparo==true){
		cout << "oviparo, ";
	}else if(oviparo==false){
		cout<< "no oviparo, ";
	}if(pico==true){
		cout<< "tiene pico y ";
	}else if(pico==false){
		cout << "no tiene pico y ";
	}if(vuela==true){
		cout << "vuela."<<endl;
	}else if(vuela==false){
		cout << "no vuela."<<endl;
	}
}

