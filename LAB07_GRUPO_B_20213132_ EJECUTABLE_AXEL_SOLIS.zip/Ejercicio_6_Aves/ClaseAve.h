#pragma once
#include <iostream> //Axel Jhuan Solis Zamata
#include <string>
using namespace std;
class ClaseAve{
	protected:
		bool vertebrado;
		bool oviparo;
		bool pico;
		bool vuela;
	public:
		ClaseAve();
		~ClaseAve();
		void MetodoAve();
};
