#include "stdafx.h"
#include <iostream> //Axel Jhuan Solis Zamata
#include "DerivadaGanso.h"
#include "DerivadaPato.h"
#include "DerivadaGallina.h"
#include <string>
int main(){
	bool vertebrados{false}, oviparos{false}, pico{false}, vuela{false};
	DerivadaGanso animal1 = DerivadaGanso(true, true, true, true);
	animal1.MetodoGanso();
	animal1.MetodoAve();
	DerivadaPato animal2 = DerivadaPato(true, true, true, true);
	animal2.MetodoPato();
	animal2.MetodoAve();
	DerivadaGallina animal3 = DerivadaGallina(true, true, true, false);//Pueden dan "vuelos explosivos" pero no pueden mantenerse en el aire a diferencia de otras aves
	animal3.MetodoGallina();
	animal3.MetodoAve();
	system("pause");
}
