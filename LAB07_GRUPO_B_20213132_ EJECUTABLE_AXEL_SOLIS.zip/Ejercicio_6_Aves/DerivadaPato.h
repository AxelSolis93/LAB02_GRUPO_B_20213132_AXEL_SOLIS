#pragma once
#include <iostream> //Axel Jhuan Solis Zamata
#include "ClaseAve.h"
#include <string>
using namespace std;
class DerivadaPato:public ClaseAve{
	private:
		bool vertebrado;
		bool oviparo;
		bool pico;
		bool vuela;
	public:
		DerivadaPato(bool,bool,bool,bool);
		~DerivadaPato();
		void MetodoPato();
};
