#pragma once
#include <iostream> //Axel Jhuan Solis Zamata
#include <string>
using namespace std;
class ClaseColor{
	protected:
		int r;
		int g;
		int b;
	public:
		ClaseColor();
		~ClaseColor();
		void MetodoColor();
};
