#include "stdafx.h"
#include <iostream> //Axel Jhuan Solis Zamata
#include "DerivadaObjeto.h"
#include <string>
int main(){
	int r{0},g{0},b{0};
	string material,objeto;
	cout << "Ingrese el valor de r, g y b(r g b): " << endl;
	cin>>r>>g>>b;
	cout << "Ingrese el material del objeto: " << endl;
	cin>>material;
	cout << "Ingrese el nombre del objeto: " << endl;
	cin>>objeto;
	DerivadaObjetos obj1 = DerivadaObjetos(r,g,b, material, objeto);
	obj1.MetodoObjetos();
	obj1.MetodoColor();
	obj1.MetodoMaterial();
	system("pause");
}
