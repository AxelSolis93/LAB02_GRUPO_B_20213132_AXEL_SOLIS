#pragma once
#include <iostream> //Axel Jhuan Solis Zamata
#include "ClaseColor.h"
#include "ClaseMaterial.h"
#include <string>
using namespace std;
class DerivadaObjetos:public ClaseColor, public ClaseMaterial{
	private:
		int r;
		int g;
		int b;
		string material;
		string objeto;
	public:
		DerivadaObjetos(int,int,int,string,string);
		~DerivadaObjetos();
		void MetodoObjetos();
};
