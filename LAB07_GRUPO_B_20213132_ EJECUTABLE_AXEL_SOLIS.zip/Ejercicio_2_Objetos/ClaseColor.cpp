#include "stdafx.h"
#include <iostream> //Axel Jhuan Solis Zamata
#include "ClaseColor.h"
#include <string>
using namespace std;
ClaseColor::ClaseColor()
{
}
ClaseColor::~ClaseColor()
{
}
void ClaseColor::MetodoColor(){;
	
}

