#include "stdafx.h"
#include <iostream> //Axel Jhuan Solis Zamata
#include "DerivadaObjeto.h"
#include <string>
using namespace std;
DerivadaObjetos::DerivadaObjetos(int _r, int _g, int _b, string _material, string _objeto){
	r = _r;
	g = _g;
	b = _b;
	material = _material;
	objeto = _objeto;
}
DerivadaObjetos::~DerivadaObjetos(){
}
void DerivadaObjetos::MetodoObjetos(){
	cout << objeto << " de color r: " << r << " g: " << g << " b: " << b << " y material de " << material << endl; 
}

