#include "stdafx.h"
#include <iostream> //Axel Jhuan Solis Zamata
#include "ClaseMaterial.h"
#include <string>
using namespace std;
ClaseMaterial::ClaseMaterial()
{
}
ClaseMaterial::~ClaseMaterial()
{
}
void ClaseMaterial::MetodoMaterial(){;
	
}

