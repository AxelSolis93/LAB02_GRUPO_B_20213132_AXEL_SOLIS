#include <iostream> //Axel Jhuan Solis Zamata
using namespace std;
int main(){
	int var1=20;
	int var2=50;
	int *apuntador = &var1;
	int *apuntador2= &var2;
	int temp = *apuntador;
	cout << "var 1 = " << *apuntador << endl;
	cout << "var 2 = " << *apuntador2 << endl;
	*apuntador = *apuntador2;
	*apuntador2 = temp;
	cout << "Intercambiando" << endl;
	cout << "var 1 = " << *apuntador << endl;
	cout << "var 2 = " << *apuntador2 << endl;
};
