#include <iostream>//Axel Jhuan Solis Zamata
using namespace std;
int sumar(int a, int b){
	return a+b;
}
int restar(int a, int b){
	return a-b;
}
int multiplicar(int a, int b){
	return a*b;
}
int dividir(int a, int b){
	return a/b;
}

int resul(int(*func)(int,int), int a, int b)
{
    return (*func)(a,b);
}
int main(){
	int oper{0}, a{0}, b{0};
    cout<<"Introduzca A y B: ";
    cin>>a>>b;
    cout << "Ingrese el numero de la operacion que desea efectuar: "<< endl;
    while(oper!=5){
    	cout << "1. Suma" << endl;
		cout << "2. Resta" << endl;
		cout << "3. Multiplicacion" << endl;
		cout << "4. Division" << endl;
		cout << "5. Salir" << endl;
		cin>>oper;
  		switch(oper){
    		case 1:cout << "La suma es: " << resul(sumar, a, b)<<endl;break;
			case 2:cout << "La resta es: " << resul(restar, a, b)<<endl;break;
			case 3:cout << "La multiplicacion es: " << resul(multiplicar, a, b)<<endl;break;
			case 4:cout << "La division es: " << resul(dividir, a, b)<<endl;break;
			case 5:break;
			default:cout<<"error, elija una opcion valida"<<endl; break;
		}
	}
   
};
