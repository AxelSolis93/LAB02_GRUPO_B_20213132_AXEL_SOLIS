#include <iostream>//Axel Jhuan Solis Zamata
#include <random>
using namespace std;
int main(){
	random_device rd;
	mt19937 mt(rd());
	uniform_real_distribution<float> dist(1.0, 100.0);
	for(int i=0;i<1000000;i++){
		float *vector1 = NULL;
		float *vector2 = NULL;
		vector1 = new float[1];
		vector2 = new float[1];
		vector1[0]=dist(mt);
		vector2[0]=dist(mt);
		cout << "Los valores aleatorios son: "<< *vector1 << " y " << *vector2 << endl;
		cout << "El producto punto es: " <<(*vector1)* (*vector2) << endl;
		delete [] vector1;
		delete [] vector2;
		vector1 = NULL;
		vector2 = NULL;
	}

};
