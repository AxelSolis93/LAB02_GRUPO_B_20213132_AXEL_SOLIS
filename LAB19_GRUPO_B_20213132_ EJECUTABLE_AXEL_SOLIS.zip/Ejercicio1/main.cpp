#include <iostream> //Axel Jhuan Solis Zamata
#include <vector>
#include <math.h>
using namespace std;
class Pairs {
	public:
		int a;
		int b;
		Pairs(int _a,int _b){
			a = _a;
			b = _b;
		}
		~Pairs(){}
};
class Formula{
	public:
		int operator()(std::vector<int> S) {//Recibe un vector de enteros y hace la sumatoria
			int cont{0};
			for(auto x:S){
				cont+=x;
			}
			return cont;
		}
		float HallaA(std::vector<Pairs> S){
			//std::vector<int> tempxy; //Removido por el cambio de formula
			std::vector<int> tempx;
			//std::vector<int> tempy;
			std::vector<int> tempx2;
			//for(auto x:S){
			//	tempxy.push_back(x.a*x.b); //Valores de x*y
			//}
			for(auto x:S){
				tempx.push_back(x.a);//Valores de x
			}
			//for(auto x:S){
			//	tempy.push_back(x.b);//Valores de y
			//}
			for(auto x:S){
				tempx2.push_back(x.a*x.a);//Valores de x al cuadrado
			}
			Formula formtemp; //Para usar los functores y hacer la sumatoria de valores especificos
			//cout<<formtemp(tempxy)<<endl;
			
			float mult = sqrt((formtemp(tempx2)/S.size())-(pow((formtemp(tempx)/S.size()),2))); //Formula del video mostrado, usada para ahorrar tiempo
			//((S.size()*formtemp(tempxy))-(formtemp(tempx)*formtemp(tempy)))/((S.size()*formtemp(tempx2))-(formtemp(tempx)*formtemp(tempx))); //Formula de internet
			return mult;
		}
		float HallaB(std::vector<Pairs> S){
			//std::vector<int> tempxy; //Removido por el cambio de formula
			//std::vector<int> tempx;
			std::vector<int> tempy;
			std::vector<int> tempy2;
			//for(auto x:S){
			//	tempxy.push_back(x.a*x.b); //Valores de x*y
			//}
			//for(auto x:S){
			//	tempx.push_back(x.a);//Valores de x
			//}
			for(auto x:S){
				tempy.push_back(x.b);//Valores de y
			}
			for(auto x:S){
				tempy2.push_back(x.b*x.b);//Valores de y al cuadrado
			}
			Formula formtemp;
			//cout<<formtemp(tempxy)<<endl;
			
			float mult = sqrt((formtemp(tempy2)/S.size())-(pow((formtemp(tempy)/S.size()),2)));
			return mult;
		}


};
int main()
{
	vector<Pairs> vect; //
	Pairs a(2,14);
	Pairs b(3,20);
	Pairs c(5,32);
	Pairs d(7,42);
	Pairs e(8,44);
	vect.push_back(a);
	vect.push_back(b);
	vect.push_back(c);
	vect.push_back(d);
	vect.push_back(e);
	Formula Form;
	cout << "Valor de a: " << Form.HallaA(vect) << endl;
	cout << "Valor de b: " << Form.HallaB(vect) << endl;
	cout << endl;
	system("pause");
	return 0;
}