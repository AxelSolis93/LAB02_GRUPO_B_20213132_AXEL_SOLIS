#include <iostream> //AXel Jhuan Solis Zamata
#include <vector>
using namespace std;
class FIND {
	public:
		std::vector<int> operator()(int in, int fin, int val) {
			std::vector<int> Ocurr;
			std::vector<int> vec = {1,2,3,2,4,6,9,7,6,3};
			for(int i=in; i<= fin; i++){
				if(vec.at(i)==val){
					Ocurr.push_back(i);
				}
			}
			return Ocurr;
		}
};
int main()
{
	FIND obj;
	vector<int> vect = obj(0,9,3); //
	cout << "Indices de ocurrencia: " << endl;

	for (int x : vect){
		cout << x << ", ";
	}
	cout << endl;
	system("pause");
	return 0;
}