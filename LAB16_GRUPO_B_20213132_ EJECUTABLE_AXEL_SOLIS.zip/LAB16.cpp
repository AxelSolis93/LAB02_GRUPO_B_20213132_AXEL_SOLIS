#include <iostream> //Axel Jhuan Solis Zamata
#include <string>

class WinFactory {
	public:
		virtual ~WinFactory() {};
		virtual std::string Draw() const = 0;
};

class MacFactory {
	public:
		virtual ~MacFactory() {};
		virtual std::string Draw() const = 0;
		//virtual std::string Funcion2_B(const WinFactory& colaborador) const = 0; //El esquema muestra esta parte pero en la respuesta esperada no parece ser usada
};

class LinFactory{
	public:
		virtual ~LinFactory(){};
		virtual std::string Draw() const = 0;
};
class GUIFactory {
	public:
		virtual WinFactory* CrearControlW() const = 0;
		virtual MacFactory* CrearControlM() const = 0;
		virtual LinFactory* CrearControlL() const = 0;
};

class WinButton : public WinFactory {
	public:
		std::string Draw() const override {
			return "Dibujando Button Windows.";
		}
	};
	
class WinCheckbox : public WinFactory {
	public:
		std::string Draw() const override {
			return "Dibujando Checkbox Windows.";
		}
};


class MacButton : public MacFactory {
	public:
		std::string Draw() const override {
				return "Dibujando Button Mac.";
		}
		
		/*std::string Funcion2_B(const WinFactory& colaborador) const override { //draw
			const std::string result = colaborador.Funcion1_A();
			return "B1 con ayuda de " + result;
		}*/
};

class MacCheckbox : public MacFactory {
	public:
		std::string Draw() const override {
		return "Dibujando Checkbox Mac.";
		}
};

class LinButton : public LinFactory {
	public:
		std::string Draw() const override {
			return "Dibujando Button Linux.";
		}
	};
	
class LinCheckbox : public LinFactory {
	public:
		std::string Draw() const override {
			return "Dibujando Checkbox Linux.";
		}
};

class Button : public GUIFactory {
	public:
		WinFactory* CrearControlW() const override {
			return new WinButton();
		}
		MacFactory* CrearControlM() const override {
			return new MacButton();
		}
		LinFactory* CrearControlL() const override{
			return new LinButton();
		}
};

class Checkbox : public GUIFactory {
	public:
		WinFactory* CrearControlW() const override {
			return new WinCheckbox();
		}
		MacFactory* CrearControlM() const override {
			return new MacCheckbox();
		}
		LinFactory* CrearControlL() const override {
			return new LinCheckbox();
		}
};


void Aplication(const GUIFactory& f, int os) {
	if(os==1){
		const WinFactory* producto_a = f.CrearControlW();
		std::cout << producto_a->Draw();
		delete producto_a;
	}else if(os==2){
		const MacFactory* producto_b = f.CrearControlM();
		std::cout << producto_b->Draw();
		delete producto_b;
	}else if(os==3){
		const LinFactory* producto_c = f.CrearControlL();
		std::cout << producto_c->Draw();
		delete producto_c;
	}
	
	
	
}

int main() {
std::cout << "Cliente: Windows "<<std::endl;
Button* f1 = new Button();
Aplication(*f1, 1); // 1 - Windows
delete f1;
std::cout << std::endl<<std::endl;
std::cout << "Cliente: Mac "<<std::endl;
Button* f2 = new Button();
Aplication(*f2, 2); // 2 - Mac
delete f2;
std::cout << std::endl<<std::endl;
std::cout << "Cliente: Linux "<<std::endl;
Button* f3 = new Button();
Aplication(*f3, 3); // 3 - Linux
delete f3;
std::cout << std::endl<<std::endl;
std::cout << "Cliente: Windows "<<std::endl;
Checkbox* f4 = new Checkbox();
Aplication(*f4, 1); // 1 - Windows Checkbox
delete f4;
std::cout << std::endl<<std::endl;
std::cout << "Cliente: Mac "<<std::endl;
Checkbox* f5 = new Checkbox();
Aplication(*f5, 2); // 2 - Mac Checkbox
delete f5;
std::cout << std::endl<<std::endl;
std::cout << "Cliente: Linux "<<std::endl;
Checkbox* f6 = new Checkbox();
Aplication(*f6, 3); // 3 - Linux Checkbox
delete f6;
return 0;
}