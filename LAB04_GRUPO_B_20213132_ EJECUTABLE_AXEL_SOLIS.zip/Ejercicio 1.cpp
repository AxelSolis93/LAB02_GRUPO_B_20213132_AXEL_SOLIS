#include <iostream>//Axel Jhuan Solis Zamata
#include <string>
using namespace std;
int main(){
	string nombre[3];
	string apellido[3];
	string edad[3];
	string DNI[3];
	for(int i=0;i<3;i++){
		cout << "Ingrese un nombre: " << endl;
		getline(cin, nombre[i]);
		cout << "Ingrese un apellido: " << endl;
		getline(cin, apellido[i]);
		cout << "Ingrese la edad: " << endl;
		getline(cin, edad[i]);
		cout << "Ingrese el DNI: " << endl;
		getline(cin, DNI[i]);
	}
	for(int i=0;i<3;i++){
		cout << "Datos de la persona " << i+1 << ": " << "nombre: "<< nombre[i] << " apellido: " << apellido[i] << " edad: " << edad[i] << " DNI: "<< DNI[i] << "." << endl;
	}
}
