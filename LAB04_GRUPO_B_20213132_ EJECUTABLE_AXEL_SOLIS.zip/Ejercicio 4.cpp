#include <iostream>
using namespace std;
int main(){ //Axel Jhuan Solis Zamata
	int array[100],k=0;
	bool primo=false;
	for(int i=0;i<100;i++){
		for(int j=2;j<i;j++){
			if(i%j==0){
				primo = false;
			}
		}if(primo==true){
			array[k]=i;
			k++;
		}
		primo=true;//Reinicia la condici�n en caso se haya vuelto falsa
	}
	k--;
	int aux=0;
	for(int i=0;i<k;i++){
		if(array[i]<array[i+1]){
			aux=array[i];
			array[i]=array[i+1];
			array[i+1]=aux;
		}
	}
	cout << "numeros primos del 1 al 100: ";
	for(int i=0;i<k;i++){
		cout << array[i] << " ";
	}
}
