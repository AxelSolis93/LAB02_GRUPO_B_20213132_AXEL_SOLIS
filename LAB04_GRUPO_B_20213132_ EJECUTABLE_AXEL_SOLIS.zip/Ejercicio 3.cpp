#include <iostream>//Axel Jhuan Solis Zamata
using namespace std;
int main(){
	int array[5][3];
	for(int i=0;i<5;i++){
		for(int j=0;j<3;j++){
			cout << "Ingrese un numero: " << endl;
			cin>>array[i][j];
		}
	}
	int suma=0;
	for(int i=0;i<5;i++){
		for(int j=0;j<3;j++){
			if((i+1)%2==0&&(i+1)<5){
				suma=suma+array[i][j];
			}
		}
	}
	cout << "La suma de los numeros en filas pares es: " << suma << endl;
	cout << endl << endl;
	system("pause");
}
