#include <iostream>//Axel Jhuan Solis Zamata
using namespace std;
bool buscar(int *array, int n){
	for(int i=0;i<8;i++){
		if(array[i]==n){
			return true;
		}
	}return false;
}
int main(){
	int array[8],n=0;
	for(int i=0;i<8;i++){
		cout << "ingrese un numero: " << endl;
		cin>>array[i];
	}
	cout << "Ingrese el numero a buscar: " << endl;
	cin>>n;
	if(buscar(array,n)==true){ //con cout retornaba 0 y 1.
		cout << "Verdadero"	<<endl; 
	}else{
		cout << "Falso" << endl;
	}
}
