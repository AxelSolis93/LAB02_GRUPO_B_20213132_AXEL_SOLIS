#include <iostream>//Axel Jhuan Solis Zamata
#include "Cola.h"
using namespace std;
int main(){
    bool cond{false};
    Cola<int> H; //Inicia la Cola
    Cola<int> M;

    int num{0},val1{0},val2{0},val3{0};
    cout << "Ingrese el numero de elementos de la cola Hombres: " << endl;
    cin>>num;
    for(int i=0;i<num;i++){
        cout << "Ingrese un valor para la cola Hombres: " << endl;
        cin>>val1;
        H.Push(val1);
    }
    cout << "Ingrese el numero de elementos de la cola Mujeres: " << endl;
    cin>>num;
    for(int i=0;i<num;i++){
        cout << "Ingrese un valor para la cola Mujeres: " << endl;
        cin>>val2;
        M.Push(val2);
    }
    cout << "Ingrese el numero de iteraciones " << endl;
    cin>>val3;
    for(int i=0;i<(val3)-1;i++){
        H.iter(); 
        M.iter();
    }
    cout << "Luego de " << val3 << " iteraciones: " <<endl;
    H.comp(M);
    //Lista iterada
    //H.print();
    //M.print(); 
    
    system("pause");
    return 0;
}
