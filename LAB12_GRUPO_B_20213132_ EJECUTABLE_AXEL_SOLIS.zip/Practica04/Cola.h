//Axel Jhuan Solis Zamata
#include "nodo.h"
using namespace std;
template <class T>
class Cola{
    private:
        
        Nodo<T>* extremo;
        Nodo<T>* ultimo;
    public:
        Cola(){
            extremo = NULL;   
        }
        void Push(T x){   
            if(extremo==nullptr){   
                extremo = new Nodo<T>;
                ultimo = new Nodo<T>;
                Nodo<T>* aux = new Nodo<T>;
                aux->sgte = nullptr;
                aux->datos=x;
                extremo = aux;
                ultimo = aux;
                
            }else{
                Nodo<T>* aux = new Nodo<T>;
                aux->datos = x; 
                aux->sgte = nullptr;
                ultimo->sgte = aux;
                ultimo = aux;

            }
        }


        void iter(){
            if(extremo==nullptr){   
                cout << "La Cola esta vacia"<<endl;
            }else{
                
                Nodo<T>* aux = extremo;
                extremo=extremo->sgte;
                ultimo->sgte=aux;
                ultimo=aux;
                ultimo->sgte=nullptr;
                delete aux;
                
                //ultimo->sgte=nullptr;
                //extremo->sgte=aux;
            }
            
        }

        void comp(Cola M){
            if(extremo==nullptr||M.extremo==nullptr){
                cout << "Hay por lo menos una cola vacia"<<endl;
            }else if(extremo->datos>M.extremo->datos){
                cout << "Hombres es mayor" << endl;
            }else if(M.extremo->datos>extremo->datos){
                cout << "Mujeres es mayor" <<  endl;
            }else{
                cout << "Ambos son iguales" << endl;
            }
        }

        void print(){   
            bool stop{false};
            Nodo<T>* aux = extremo;
            if(extremo==nullptr){
                cout << "La lista esta vacia" << endl;
                return;
            }
             
            while(stop==false){
                cout << aux->datos << " ";
                if(aux->sgte==nullptr){
                    stop=true;
                }
                aux = aux->sgte;
            }
            cout <<endl;
        }
};


