//Axel Jhuan Solis Zamata
#include "nodo.h"
using namespace std;
template <class T>
class Cola{
    private:       
        Nodo<T>* extremo;
        Nodo<T>* ultimo;
    public:
        Cola(){
            extremo = NULL;   
        }
        void Push(T x){   
            if(extremo==nullptr){   
                extremo = new Nodo<T>;
                ultimo = new Nodo<T>;
                Nodo<T>* aux = new Nodo<T>;
                aux->sgte = nullptr;
                aux->datos=x;
                extremo = aux;
                ultimo = aux;
                
            }else{
                Nodo<T>* aux = new Nodo<T>;
                aux->datos = x; 
                aux->sgte = nullptr;
                ultimo->sgte = aux;
                ultimo = aux;

            }
        }
        void Pop(){   
            if(extremo==nullptr){   
                cout << "La Cola esta vacia"<<endl;
            }else{
                Nodo<T>* aux = extremo;
                extremo=extremo->sgte;
                cout << "Elemento " << aux->datos << " eliminado" <<endl;
                delete aux; 
            }
        }

       
        void print(){   
            bool stop{false};
            Nodo<T>* aux = extremo;
            if(extremo==nullptr){
                cout << "La Cola esta vacia" << endl;
                return;
            }
             
            while(stop==false){
                cout << aux->datos << " ";
                if(aux->sgte==nullptr){
                    stop=true;
                }
                aux = aux->sgte;
            }
            cout <<endl;
        }
};


