#include <iostream>//Axel Jhuan Solis Zamata
#include "Cola.h"
using namespace std;
int main(){
    bool cond{false};
    Cola<int> P; //Inicia la Cola
    while(cond==false){
        int e{0};
        cout << "1. Ingresar un numero    2. Mostrar la Cola   3. Eliminar primer elemento   4. Salir"<<endl;
        cin>>e;
        switch(e){
            case 1:int x;cout<<"Ingrese el numero: "<<endl;cin>>x;P.Push(x);break;
            case 2:P.print();break;
            case 3:P.Pop();break;
            case 4:cond=true;break;
            default: cout << "Opcion invalida" << endl;break;
        }
    }
    system("pause");
    return 0;
}
