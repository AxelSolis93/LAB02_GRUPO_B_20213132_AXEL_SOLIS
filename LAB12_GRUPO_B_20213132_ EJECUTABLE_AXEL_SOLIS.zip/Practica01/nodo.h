//Axel Jhuan Solis Zamata
template <class T>
class Nodo{
    public:
        T datos;//<>
        Nodo<T>* sgte;
};
