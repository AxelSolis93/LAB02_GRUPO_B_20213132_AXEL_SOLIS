//Axel Jhuan Solis Zamata
#include "nodo.h"
using namespace std;
template <class T>
class Cola{
    private:
       
        Nodo<T>* extremo;
        Nodo<T>* ultimo;
    public:
        Cola(){
            extremo = NULL;   
        }
        void Push(T x){   
            if(extremo==nullptr){   
                extremo = new Nodo<T>;
                ultimo = new Nodo<T>;
                Nodo<T>* aux = new Nodo<T>;
                aux->sgte = nullptr;
                aux->datos=x;
                extremo = aux;
                ultimo = aux;
                
            }else{
      //          Nodo<T>* aux = new Nodo<T>; //codigo pila
    //            aux->datos = x; 
  //              aux->sgte = extremo;
//                extremo = aux; 
                Nodo<T>* aux = new Nodo<T>;
                aux->datos = x; 
                aux->sgte = nullptr;
                ultimo->sgte = aux;
                ultimo = aux;

            }
        }
        //Pop
        void print(){   
            bool stop{false};
            Nodo<T>* aux = extremo;
            //Nodo<T>* aux = ultimo; //pruebas
            //cout << extremo->datos << " ";
            if(extremo==nullptr){
                cout << "La cola esta vacia" << endl;
                return;
            }
             
            while(stop==false){
                cout << aux->datos << " ";
                if(aux->sgte==nullptr){
                    stop=true;
                }
                aux = aux->sgte;
            }
            //cout << ultimo->datos << " "; //pruebas
            cout <<endl;
        }
};


