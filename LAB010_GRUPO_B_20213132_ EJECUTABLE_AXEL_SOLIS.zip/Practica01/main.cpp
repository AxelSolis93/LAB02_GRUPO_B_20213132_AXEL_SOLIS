#include <iostream>//Axel Jhuan Solis Zamata
#include "Lista.h"
using namespace std;
int main(){
    Listaenlazada lista = NULL;//lista vacia
    int _dato{0};
    while(_dato!=-1){
        cout << "Elemento a ingresar(-1 si quiere detener el bucle): " << endl;
        cin>>_dato;
        if(_dato!=-1){
            Insertar(lista, _dato);
        }
    }
    print(lista);
    return 0;
}
