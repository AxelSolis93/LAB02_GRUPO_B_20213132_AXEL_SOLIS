//Axel Jhuan Solis Zamata
#include <iostream>
using namespace std;
struct nodo{
       int nro;
       struct nodo *sgte;
};
 
typedef struct nodo *Listaenlazada;

Listaenlazada Crear(int n){ 
    Listaenlazada nuevo = new(struct nodo);
    nuevo ->nro=n;
    nuevo->sgte=NULL;
    return nuevo;
}

void Insertar(Listaenlazada &lista, int n){
    if(lista==NULL){ //Si la lista está vacía, crea el primer elemento
        lista = Crear(n);
    }else{
        Insertar(lista->sgte, n); //recursión que pone el valor siempre al final, será útil cuando se compliquen más los nodos y listas 
    }
}

void print(Listaenlazada &lista){
    while(lista!=NULL){
        if(lista->sgte!=NULL){//verifica que el siguiente numero no sea nulo
            cout << lista->nro << " | ";
        }else{
            cout << lista->nro<<endl;;//endline ya que no hay más números
        }
        lista = lista->sgte;
    }
}
