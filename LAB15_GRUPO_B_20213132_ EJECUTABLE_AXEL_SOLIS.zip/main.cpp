#include "iostream" //Axel Jhuan Solis Zamata
#include "vector"
#include <string>
using namespace std;
struct details{ //Estructura con nombre del componente y color
	std::string name;
	std::string color;
};
class Producto1 {
public:
std::vector<details> componentes;
void ListaComp()const {
std::cout << "Componentes : ";
for (size_t i = 0; i < componentes.size(); i++) {
if (componentes[i].name == componentes.back().name) {
std::cout << componentes[i].name << " color " << componentes[i].color;
}
else {
std::cout << componentes[i].name << " color " << componentes[i].color<< ", ";
}
}
std::cout << "\n\n";
}
};
/* La interfaz de Builder especifica m?todos para crear las diferentes partes
de los objetos Product. */
class IBuilder {
public:
virtual ~IBuilder() {}
virtual void ProducirPuertas() const = 0;
virtual void ProducirLlantas() const = 0;
virtual void ProducirTimon() const = 0;
virtual void ProducirAsientos() const = 0;
virtual void ProducirMotor() const = 0;
virtual void ProducirEspejos() const = 0;
virtual void ProducirVidrios() const = 0;
};
/* Las clases de BuilderEspecifico siguen la interfaz de Builder y proporcionan
implementaciones espec?ficas de los pasos de construcci?n. El programa puede
tener varias variaciones de Builders, implementadas de manera diferente. */
class BuilderEspecifico : public IBuilder {
private:
Producto1* product;
public:
BuilderEspecifico() {
this->Reset();
}
~BuilderEspecifico() {
delete product;
}
void Reset() {
this->product = new Producto1();
}
void ProducirPuertas()const override {
	string color;
	cout << "�De que color quiere sus puertas?: " << endl;
	cin >> color;
	details temp{"Puertas",color};
	this->product->componentes.push_back(temp);
}
void ProducirLlantas()const override {
	string color;
	cout << "�De que color quiere sus llantas?: " << endl;
	cin >> color;
	details temp{"Llantas",color};
	this->product->componentes.push_back(temp);
}
void ProducirTimon()const override {
	string color;
	cout << "�De que color quiere su Timon?: " << endl;
	cin >> color;
	details temp{"Timon",color};
	this->product->componentes.push_back(temp);
}
void ProducirAsientos()const override {
	string color;
	cout << "�De que color quiere sus asientos?: " << endl;
	cin >> color;
	details temp{"Asientos",color};
	this->product->componentes.push_back(temp);
}
void ProducirMotor()const override {
	string color;
	cout << "�De que color quiere su motor?: " << endl;
	cin >> color;
	details temp{"Motor",color};
	this->product->componentes.push_back(temp);
}
void ProducirEspejos()const override {
	string color;
	cout << "�De que color quiere sus espejos?: " << endl;
	cin >> color;
	details temp{"Espejos",color};
	this->product->componentes.push_back(temp);
}
void ProducirVidrios()const override {
	string color;
	cout << "�De que color quiere sus vidrios?: " << endl;
	cin >> color;
	details temp{"Vidrios",color};
	this->product->componentes.push_back(temp);
}

Producto1* GetProducto() {
Producto1* resultado = this->product;
this->Reset();
return resultado;
}
};
/*El Director solo es responsable de ejecutar los pasos de construcci?n en una
secuencia particular. Es ?til cuando se fabrican productos de acuerdo con un
pedido o configuraci?n espec?ficos. Estrictamente hablando, la clase Director
es opcional, ya que el cliente puede controlar directamente a los
constructores.*/
/*class Director {
private:
IBuilder* builder;
public:
void set_builder(IBuilder* builder) {
this->builder = builder;
}
void BuildProductoMin() {
this->builder->ProducirParteA();
}
void BuildProductoCompleto() {
this->builder->ProducirParteA();
this->builder->ProducirParteB();
this->builder->ProducirParteC();
}
};
*/
/* El c?digo del cliente crea un objeto constructor, se lo pasa al director y
luego inicia el proceso de construcci?n. El resultado final se recupera del
objeto constructor. */
void ClienteCode(/*Director& director*/)
{
BuilderEspecifico* builder = new BuilderEspecifico();
/*director.set_builder(builder);
std::cout << "Producto Basico:\n";
director.BuildProductoMin();
Producto1* p = builder->GetProducto();
p->ListaComp();
delete p;
std::cout << "Producto Completo:\n";
director.BuildProductoCompleto();
p = builder->GetProducto();
p->ListaComp();
delete p;
*/
int Elec;
bool pu{false},l{false},t{false},a{false},m{false},e{false}; //Evitar que se vuelva a poner un componente ya puesto
while(Elec!=7){
	std::cout << "Elija los componentes que desee: 1. puerta 2. llantas 3. timon 4. asientos 5. motor 6. espejos 7. Salir"<<endl;
	cin>>Elec;
	switch(Elec){
		case 1:if(pu==false){builder->ProducirPuertas();pu=true;}else{cout<<"Ya existen puertas " << endl;};break;
		case 2:if(l==false){builder->ProducirLlantas();l=true;}else{cout<<"Ya existen llantas " << endl;};break;
		case 3:if(t==false){builder->ProducirTimon();t=true;}else{cout<<"Ya existe un timon " << endl;};break;
		case 4:if(a==false){builder->ProducirAsientos();a=true;}else{cout<<"Ya existen asientos " << endl;};break;
		case 5:if(m==false){builder->ProducirMotor();m=true;}else{cout<<"Ya existe un motor " << endl;};break;
		case 6:if(e==false){builder->ProducirEspejos();e=true;}else{cout<<"Ya existen espejos " << endl;};break;
		case 7:break;
		default:break;
	}		
}

//builder->ProducirParteA();
//builder->ProducirParteC();
Producto1* p = builder->GetProducto();
p->ListaComp();
delete p;
delete builder;
}

int main() {
//Director* director = new Director(); //Director opcional
ClienteCode(/**director*/);
//delete director;
return 0;
}


