#include <iostream>
using namespace std;
//Axel Jhuan Solis Zamata
int funcion(int x){
	if(x%2==0){
		int suma=0;
		for(int i=0;i<x;i++){
			if(i%2!=0){
				suma=suma+i;
			}
		}
		return suma;
	}else{
		cout << "El numero no es par" << endl;
		return 0;
	}
	
}
	
int main()
{
	int x=0;
	bool entre=false;
	while(entre==false){
		cout << "Ingresar un numero entre 0 y 100: " << endl;
		cin>>x;
		if(x<0||x>100){
			entre=false;
			cout << "El numero que ingreso no es valido"<<endl;
		}else{
			entre=true;
		}
	}
	if(funcion(x)==0){
		cout << "error, numero impar"<<endl;
	}else{
		cout << "La suma de los numeros impares del 0 al " << x << " son: " << funcion(x);
	}
	cout << endl << endl;
	system("pause");
}
