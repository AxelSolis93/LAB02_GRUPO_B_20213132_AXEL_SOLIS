#include <iostream>
using namespace std;
int pot(int a, int b){
	cout << "La potencia es: ";
	int res=a;//Almacena el resultado
	for(int i=0;i<b-1;i++){
		res=res*a;
	}	
	cout << res << endl;
}
int main()
{
    int a=0,b=0;
	cout << "Ingrese un numero: "<<endl;
	cin>>a;
	cout << "Ingrese el exponente: "<<endl;
	cin>>b;
	pot(a,b);
	cout << endl << endl;
	system("pause");
}
