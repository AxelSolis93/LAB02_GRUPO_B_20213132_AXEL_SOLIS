#include <iostream>//Axel Jhuan Solis Zamata
using namespace std;

int prim(int max){
	int cont=0;
	bool primo=false;
		for(int i=2;i<max;i++){
			for(int j=2;j<i;j++){
				if(i%j==0){
					primo = false;
				}
			}if(primo==true){
			cout << i << " ";
			cont++;
		}	primo=true;
		}
	
	}

int main()
{
	int x=0;
	cout << "Ingrese hasta que numero quiere hallar los numeros primos: " << endl;
	cin>>x;
	cout << "Los numeros primos del 1 al " << x << " son: 2 ";
	prim(x);
	cout << endl << endl;
	system("pause");
}
