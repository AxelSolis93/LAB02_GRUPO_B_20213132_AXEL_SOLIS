#include <iostream>
using namespace std;
int bisiesto(int a){
	if(a%4==0){
		cout << a << " es bisiesto" << endl;
	}else{
		cout << a << " no es bisiesto" << endl;
	}
}
int main()//Axel Jhuan Solis Zamata
{
	int a=0;
	cout << "Ingrese un a�o: " << endl;
	cin>>a;
	bisiesto(a);
	cout << endl << endl;
	system("pause");
}
