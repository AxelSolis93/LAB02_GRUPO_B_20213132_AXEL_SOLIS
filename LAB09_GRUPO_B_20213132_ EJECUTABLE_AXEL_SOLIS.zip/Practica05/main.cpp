#include <iostream>//Axel Jhuan Solis Zamata
#include "sort.h"
using namespace std;
int main(){
    int ArrayEntero[]={5,7,2,8,6};
    float ArrayFloat[]={10.1,8.4,3.6,4.4,11.2};
    sort <int> num1(ArrayEntero);
    sort <float> num2(ArrayFloat);
    cout << "Primer grupo en orden ascendente: " << num1.ascendente() << endl;
    cout << "Primer grupo en orden descendente: " << num1.descendente() << endl;
    cout << "Segundo grupo en orden ascendente: " << num2.ascendente() << endl;
    cout << "Segundo grupo en orden descendente: " << num2.descendente() << endl;
    system("pause");
    return 0;
}
