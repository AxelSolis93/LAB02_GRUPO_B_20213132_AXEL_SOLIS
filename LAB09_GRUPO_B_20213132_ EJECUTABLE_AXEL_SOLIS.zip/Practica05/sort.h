//Axel Jhuan Solis Zamata
template <class T>
class sort{
    private:
        T x[5];
    public:
        sort(T[5]);
        T ascendente(){
            T aux;
            for(int i=0;i<5;i++){
                for(int j=0;j<5;j++){
                    if(x[i]<x[j]){
                        aux = x[i];
                        x[i]=x[j];
                        x[j]=aux;
                    }
                }
            }
            for(int i=0;i<4;i++){
                std::cout<<x[i]<<" "; //Si se usa return, se acabaría la función antes de dar toda la lista
            }
            return x[4];//Final
        };
        T descendente(){
            T aux;
            for(int i=0;i<5;i++){
                for(int j=0;j<5;j++){
                    if(x[i]>x[j]){
                        aux = x[i];
                        x[i]=x[j];
                        x[j]=aux;
                    }
                }
            }
            for(int i=0;i<4;i++){
                std::cout<<x[i]<<" "; //Si se usa return, se acabaría la función antes de dar toda la lista
            }
            return x[4];//Final
        };
};
template <class T>
sort<T>::sort(T x[]){
    for(int i=0;i<5;i++){
        this->x[i]=x[i];
    }
}
