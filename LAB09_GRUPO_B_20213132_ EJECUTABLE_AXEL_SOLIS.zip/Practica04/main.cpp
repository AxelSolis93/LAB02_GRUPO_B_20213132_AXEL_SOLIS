#include <iostream>//Axel Jhuan Solis Zamata
#include "MinimoMaximo.h"
using namespace std;
int main(){
    int ArrayEntero[]={10,7,2,8,6};
    float ArrayFloat[]={12.1,8.7,5.6,8.4,1.2};
    MinimoMaximo <int> num1(ArrayEntero);
    MinimoMaximo <float> num2(ArrayFloat);
    cout << "Primer grupo, numero mayor: " << num1.mayor() << endl;
    cout << "Primer grupo, numero menor: " << num1.menor() << endl;
    cout << "Segundo grupo, numero mayor: " << num2.mayor() << endl;
    cout << "Segundo grupo, numero menor: " << num2.menor() << endl;
    system("pause");
    return 0;
}
