//Axel Jhuan Solis Zamata
template <class T>
class MinimoMaximo{
    private:
        T x[5];
    public:
        MinimoMaximo(T[5]);
        T mayor(){
            T aux=x[0];
            for(int i=0;i<5;i++){
                if(x[i]>aux){
                    aux = x[i];
                }
            }
            return aux;
        };
        T menor(){
            T aux=x[0];
            for(int i=0;i<5;i++){
                if(x[i]<aux){
                    aux = x[i];
                }
            }
            return aux;
        };
};
template <class T>
MinimoMaximo<T>::MinimoMaximo(T x[5]){
    for(int i=0;i<5;i++){
        this->x[i]=x[i];
    }
}
