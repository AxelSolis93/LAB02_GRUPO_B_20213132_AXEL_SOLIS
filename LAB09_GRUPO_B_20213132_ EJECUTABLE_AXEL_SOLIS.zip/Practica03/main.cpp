#include <iostream>//Axel Jhuan Solis Zamata
#include <string>
#include "correo.h"
using namespace std;
int main(){
    correo <char> dat1('a','e','s','c','d');
    correo <string> dat2("solis","castro","contreras","gutierrez","acosta");
    cout << "El primero correo es: " << dat1.geta() << dat2.geta() << "@unsa.edu.pe"<<endl;
    cout << "El segundo correo es: " << dat1.getb() << dat2.getb() << "@unsa.edu.pe"<<endl;
    cout << "El tercer correo es: " << dat1.getc() << dat2.getc() << "@unsa.edu.pe"<<endl;
    cout << "El cuarto correo es: " << dat1.getd() << dat2.getd() << "@unsa.edu.pe"<<endl;
    cout << "El quinto correo es: " << dat1.gete() << dat2.gete() << "@unsa.edu.pe"<<endl;
    system("pause");
    return 0;
}
