//Axel Jhuan Solis Zamata
template <class T>
class correo{
    private:
        T a;
        T b;
        T c; 
        T d;
        T e;
    public:
        correo(T a, T b, T c, T d, T e);
        T geta(){
            return a;
        };
        T getb(){
            return b;
        };
         T getc(){
            return c;
        };
         T getd(){
            return d;
        };
         T gete(){
            return e;
        };
};
template <class T>
correo<T>::correo(T a, T b, T c, T d, T e){
    this->a=a;
    this->b=b;
    this->c=c;
    this->d=d;
    this->e=e;
}
