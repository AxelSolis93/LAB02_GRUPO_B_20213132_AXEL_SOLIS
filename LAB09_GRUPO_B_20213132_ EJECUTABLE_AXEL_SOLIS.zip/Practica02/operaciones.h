//Axel Jhuan Solis Zamata
template <class T>
class operaciones{
    private:
        T x;
        T y;
    public:
        operaciones(T x=0, T y=0);
        T suma(){
            return x+y;
        };
        T resta(){
            return x-y;
        };
        T mult(){
            return x*y;
        };
        T div(){
            return x/y;
        };
};
template <class T>
operaciones<T>::operaciones(T x, T y){
    this->x=x;
    this->y=y;
}
