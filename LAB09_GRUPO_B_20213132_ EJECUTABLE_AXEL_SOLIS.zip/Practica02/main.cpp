#include <iostream>//Axel Jhuan Solis Zamata
#include "operaciones.h"
using namespace std;
int main(){
    operaciones <int> num1(5,3);
    operaciones <float> num2(6.6,2.4);
    cout << "La suma de los numeros del primer grupo es: " << num1.suma() << endl;
    cout << "La resta de los numeros del primer grupo es: " << num1.resta() << endl;
    cout << "La multiplicacion de los numeros del primer grupo es: " << num1.mult() << endl;
    cout << "La division de los numeros del primer grupo es: " << num1.div() << endl;
    
    cout << "La suma de los numeros del segundo grupo es: " << num2.suma() << endl;
    cout << "La resta de los numeros del segundo grupo es: " << num2.resta() << endl;
    cout << "La multiplicacion de los numeros del segundo grupo es: " << num2.mult() << endl;
    cout << "La division de los numeros del segundo grupo es: " << num2.div() << endl;
    system("pause");
    return 0;
}
