#include <iostream>//Axel Jhuan Solis Zamata
#include "MinMax.h"
using namespace std;
int main(){
    MinMax <int> num1(2,5,3);
    MinMax <float> num2(4.5,4.4,2.0);
    cout << "El numero minimo del primero grupo de numeros es: " << num1.getmin() << endl;
    cout << "El numero mayor del primero grupo de numeros es: " << num1.getmax() << endl;
    cout << "El numero minimo del segundo grupo de numeros es: " << num2.getmin() << endl;
    cout << "El numero mayor del segundo grupo de numeros es: " << num2.getmax() << endl;
    system("pause");
    return 0;
}
