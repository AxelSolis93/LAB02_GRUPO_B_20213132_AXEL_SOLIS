//Axel Jhuan Solis Zamata
template <class T>
class MinMax{
    private:
        T x;
        T y;
        T z;
    public:
        MinMax(T x=0, T y=0, T z=0);
        T getmin(){
            if(x<y&&x<z){
                return x;
            }else if(y<x&&y<z){
                return y;
            }else if(z<x&&z<y){
                return z;
            }
            return 0;//Si no lo pongo, sale error -Wreturn-type
        };
        T getmax(){
            if(x>y&&x>z){
                return x;
            }else if(y>x&&y>z){
                return y;
            }else if(z>x&&z>y){
                return z;
            }
            return 0;
        };
};
template <class T>
MinMax<T>::MinMax(T x, T y, T z){
    this->x=x;
    this->y=y;
    this->z=z;
}
