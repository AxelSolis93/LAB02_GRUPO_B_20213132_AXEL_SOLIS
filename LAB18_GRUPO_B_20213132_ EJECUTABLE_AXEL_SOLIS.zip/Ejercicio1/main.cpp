
#include <iostream> //Axel Jhuan Solis Zamata
using namespace std;
template <int N>
struct Factorial
{
	enum { value = N%10 + Factorial <N / 10>::value };
};
template <>
struct Factorial <0>
{
	enum { value = 0 };
};
int main()
{
	int x = Factorial<432>::value;
	cout << x << endl;
	return 0;
	system("pause");
}