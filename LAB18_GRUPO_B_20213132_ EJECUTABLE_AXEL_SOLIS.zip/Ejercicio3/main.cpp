
#include <iostream> //Axel Jhuan Solis Zamata
using namespace std;
template <int N, int M>
struct Potencia
{
	enum { value = N * Potencia <N,M -1>::value };
};
template <int N>
struct Potencia <N,0>
{
	enum { value = 1 };
};
int main()
{
	int x = Potencia<6,5>::value;
	cout << x << endl;
	return 0;
	system("pause");
}