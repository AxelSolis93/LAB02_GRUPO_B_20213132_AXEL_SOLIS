
#include <iostream> //Axel Jhuan Solis Zamata
using namespace std;
template <int N>
struct Fibonacci
{
	enum { value = N + Fibonacci <N -1>::value };
};
template <>
struct Fibonacci <0>
{
	enum { value = 0 };
};
int main()
{
	int x = Fibonacci<10>::value;
	cout << x << endl;
	return 0;
	system("pause");
}