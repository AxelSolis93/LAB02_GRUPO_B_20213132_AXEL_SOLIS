
#include <iostream> //Axel Jhuan Solis Zamata
using namespace std;
template <typename T>
class Operaciones {
private:
T num; 
T num2;

public:
Operaciones(T a, T b); 
T suma();
T resta();
T mult();
T div();
};
template <typename T>
Operaciones<T>::Operaciones(T a, T b)
{
num = a;
num2 = b;

}
template <typename T>
T Operaciones<T>::suma()
{
	return num+num2;
}
template <typename T>
T Operaciones<T>::resta()
{
	return num-num2;
}
template <typename T>
T Operaciones<T>::mult()
{
	return num*num2;
}
template <typename T>
T Operaciones<T>::div()
{
	return num/num2;
}
int main()
{
Operaciones<float> a(2.4,5);
cout << a.suma() << endl;
cout << a.resta() << endl;
cout << a.mult() << endl;
cout << a.div() << endl;
system("pause");
return 0;
}