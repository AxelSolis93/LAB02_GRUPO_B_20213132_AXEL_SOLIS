#include <iostream>
using namespace std;//Axel Jhuan Solis Zamata
template<class T>
class Contendor{//contendor
	T elemento;
	public: 
		Contendor(T arg){
			elemento = arg;
		}
		T add(){
			return ++elemento; //aumenta 1
		}

};
template <>
class Contendor<char>{
	char elemento;
	public:
		Contendor(char arg){
			elemento=arg;
		}
		char uppercase(){
			if((elemento>='a')&&(elemento<='z')){ //Verifica si el elemento esta entre la a minuscula o la z minuscula
				elemento+= 'A'-'a'; //x-=32
			}
			return elemento;
		}
};
int main(){
	Contendor<int> cint{5}; 
	Contendor<char> cchar('t');
	cout<< cint.add() << endl;
	cout << cchar.uppercase() << endl;
	return 0;

}