#include <iostream> //Axel Jhuan Solis Zamata
using namespace std;
class Alum{
	private:
		int CUI;
		string Nombre;
		float nota1;
		float nota2;
		float nota3;
	public:
		Alum(int,string,float,float,float);
		~Alum();
		void Promed();
};
