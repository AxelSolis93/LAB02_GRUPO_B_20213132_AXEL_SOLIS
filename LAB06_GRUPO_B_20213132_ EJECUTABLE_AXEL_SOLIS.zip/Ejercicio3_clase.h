#include <iostream> //Axel Jhuan Solis Zamata
using namespace std;
class Persona{
	private:
		string Nombre;
		string Nacimiento;
		string Fecha;
	public:
		Persona(string,string,string);
		~Persona();
		void Edad();
};
