#include <iostream> //Axel Jhuan Solis Zamata
#include <random>
#include <ctime>
#include "Ejercicio5_clase.h"
using namespace std;
Matriz::Matriz(int _Array[3][3],int _n){
	for(int i=0;i<3;i++){
		for(int j=0;j<3;j++){
			Array[i][j]=_Array[i][j];
		}
	}
	n = _n;
}
Matriz::~Matriz(){
}
void Matriz::Busqueda(){
	bool Encontrado = false;
	for(int i=0;i<3;i++){
		for(int j=0;j<3;j++){
			if(Array[i][j]==n){
				cout << "La posicion del numero " << n << " es: " << endl;
				cout << "Columna: " << j+1 << endl;
				cout << "Fila: " << i+1 << endl;
				Encontrado = true;
			}
		}
	}
	if(Encontrado==false){
		cout << "Valor no encontrado." << endl;
	}
}
int main(){
	minstd_rand mt(time(NULL));
	uniform_int_distribution<int> dist(1, 9);
	int Array[3][3];
	int Used[9],tempx{0}; //Numeros usados.
	for(int i=0;i<3;i++){
		for(int j=0;j<3;j++){
			int temp=dist(mt);
			bool Usado=false;
			for(int k=0;k<9;k++){
				if(temp==Used[k]){
					Usado=true;
					j--;					
				}
			}
			if(Usado==false){
				Array[i][j]=temp;
				Used[tempx]=temp;
				tempx++;
				Usado=true;
			}	
		}
	}
	cout << "La matriz generada aleatoriamente es: " << endl;
	for(int i=0;i<3;i++){
		for(int j=0;j<3;j++){
			cout << Array[i][j]<<" ";
		}cout << endl;
	}
	int n{0};
	cout << "Ingrese el numero del que desea hallar la posicion: " << endl;
	cin >> n;
	Matriz m1 = Matriz(Array,n);
	m1.Busqueda();
};
