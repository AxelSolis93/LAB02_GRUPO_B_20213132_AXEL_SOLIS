#include <iostream> //Axel Jhuan Solis Zamata
#include <string>
#include "Ejercicio3_clase.h"
using namespace std;
Persona::Persona(string _Nombre, string _Nacimiento, string _Fecha){
	Nombre = _Nombre;
	Nacimiento = _Nacimiento;
	Fecha = _Fecha;
}
Persona::~Persona(){
}
void Persona::Edad(){
	string Day,Month,Year,TempMonth, Year2;
	int Pos = Nacimiento.find(' ');
	Day = Nacimiento.substr(0,Pos);
	Month = Nacimiento.substr(Pos+1,Nacimiento.length());//Imprime desde el primer espacio hacia adelante
	int Pos2 = Month.find(' ');//Detecta el siguiente espacio
	TempMonth = Month;
	Month = Month.substr(0,Pos2); //Reemplaza el Month para imprimirlo sin el a�o.
	Year = TempMonth.substr(Pos2+1,TempMonth.length());
	int Pos3 = Fecha.find(' ');
	Year2 = Fecha.substr(Pos3+1,Fecha.length());
	int Pos4 = Year2.find(' ');
	Year2 = Year2.substr(Pos4+1,Year2.length());
	cout << Year2 << endl;
	int NumericYear{0};
	int NumericYear2{0};
	NumericYear = stoi(Year);
	NumericYear2 = stoi(Year2);
	int Edad{0};
	if(NumericYear>NumericYear2){
		Edad = NumericYear - NumericYear2;
	}else if(NumericYear<NumericYear2){
		Edad = NumericYear2 - NumericYear;
	}else{
		cout << Nombre << "Nacio este mismo a�o. " << endl;
	}
	
	cout << Nombre<< ", tu edad es: " << Edad << endl;
}


int main(){
	string nac,act,nom;
	cout << "Ingrese su nombre: " << endl;
	getline(cin,nom);
	cout << "Ingrese su fecha de nacimiento separada por espacios(DD/MM/AAAA): " << endl;
	getline(cin,nac);
	cout << "Ingrese la fecha actual separada por espacios(DD/MM/AAAA): " << endl;
	getline(cin,act);
	Persona p1 = Persona(nom,nac,act);
	p1.Edad();
};
