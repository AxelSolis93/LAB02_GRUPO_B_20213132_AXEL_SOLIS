#include <iostream> //Axel Jhuan Solis Zamata
using namespace std;
class Matriz{
	private:
		int Array[3][3];
		int n;
	public:
		Matriz(int[3][3],int);
		~Matriz();
		void Busqueda();
};
