#include <iostream> //Axel Jhuan Solis Zamata
using namespace std;
class Rect{
	private:
		int ancho;
		int largo;
	public:
		Rect(int,int);
		~Rect();
		void Perim();
		void Area();
};
