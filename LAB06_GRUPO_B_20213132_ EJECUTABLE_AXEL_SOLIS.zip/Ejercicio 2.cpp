#include <iostream> //Axel Jhuan Solis Zamata
#include <string>
#include "Ejercicio2_clase.h"
using namespace std;
Alum::Alum(int _CUI, string _Nombre, float _nota1, float _nota2, float _nota3){
	CUI = _CUI;
	Nombre = _Nombre;
	nota1 = _nota1;
	nota2 = _nota2;
	nota3 = _nota3;
}
Alum::~Alum(){
}
void Alum::Promed(){
	int Pos = Nombre.find(' '); //Detecta la ubicaci�n del primer espacio en el nombre para luego, en el cout, eliminar lo que haya adelante.
	cout << "CUI: " << CUI << ", nombre: " << Nombre.substr(0,Pos) << ", promedio: " << (nota1+nota2+nota3)/3 << ", usted esta ";
	if((nota1+nota2+nota3)/3>=10.5){
		cout << "Aprobado."<<endl;
	}else{
		cout << "Desaprobado." << endl;
	}
}


int main(){
	Alum a1 = Alum(20213132,"Axel Jhuan Solis Zamata",12,15,11);
	a1.Promed();
};
