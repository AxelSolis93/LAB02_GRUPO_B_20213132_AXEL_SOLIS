#include <iostream> //Axel Jhuan Solis Zamata
#include "Ejercicio1_clase.h"
using namespace std;
Rect::Rect(int _ancho, int _largo){
	ancho = _ancho;
	largo = _largo;
}
Rect::~Rect(){
}
void Rect::Perim(){
	cout << "El perimetro es " << 2*(ancho+largo)<<endl;  
}

void Rect::Area(){
	cout << "El area del rectangulo es " << ancho*largo << endl; 
}
int main(){
	Rect r1 = Rect(20,50);
	r1.Perim();
	r1.Area();
};
