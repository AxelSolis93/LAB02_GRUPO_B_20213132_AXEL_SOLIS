#pragma once  //Axel Jhuan Solis Zamata
#include "ClaseForma.h"
class ClaseRectangulo : public ClaseForma{
    protected:
        float ladomen;
        float ladomay;
    public:
        ClaseRectangulo(string, double, double, string, float, float);
        ~ClaseRectangulo();
        void imprimir();
        void area();
        void perimetro();
        void resize(float);
};