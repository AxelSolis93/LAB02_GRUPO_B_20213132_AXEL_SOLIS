#pragma once  //Axel Jhuan Solis Zamata
#include "ClaseRectangulo.h"
class ClaseCuadrado : public ClaseRectangulo{
    public:
        ClaseCuadrado(string, double, double, string, float, float);
        ~ClaseCuadrado();
        void imprimir();
        void area();
        void perimetro();
        void resize(float);
};