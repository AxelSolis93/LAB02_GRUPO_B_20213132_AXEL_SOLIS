#include "stdafx.h"
#include "ClaseForma.h" //Axel Jhuan Solis Zamata
#include <iostream>
using namespace std;
ClaseForma::ClaseForma(string _color, double _x, double _y, string _nombre){
    color = _color;
    x = _x;
    y = _y;
    nombre = _nombre;
}
ClaseForma::~ClaseForma(){

}
void ClaseForma::imprimir(){
    cout << "Color: " << color << endl;
    cout << "Coordenadas del centro en x: " << x << endl;
    cout << "Coordenadas del centro en y:" << y << endl;
    cout << "Nombre de la figura: " << nombre << endl;
}
