#pragma once  //Axel Jhuan Solis Zamata
#include<iostream>
#include <string>

using namespace std;
class ClaseForma{
    private:
        string color;
        double x;
        double y;
        string nombre;
    public:
        ClaseForma(string, double, double, string);
        ~ClaseForma();
        virtual void imprimir();
        void cambiarcolor();
        string getcolor(){
            return color;
        };
        void setcolor(string _color){
            color = _color;
        };
        void mover(double _x, double _y){
            x = _x;
            y = _y;
        };
};
