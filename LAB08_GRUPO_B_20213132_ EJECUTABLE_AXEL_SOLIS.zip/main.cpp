#include "stdafx.h" //Axel Jhuan Solis Zamata
#include "ClaseRectangulo.h"
#include "ClaseElipse.h"
#include "ClaseCuadrado.h"
#include "ClaseCirculo.h"
#include <iostream>
using namespace std;
int main(){
    string color,nombre;
    double x,y;
    //float ladomen,ladomay;
    float radiomen,radiomay;
    
    cout << "Ingrese el nombre: "<< endl;
    cin>>nombre;
    cout << "Ingrese el color: "<< endl;
    cin>>color;
    cout << "Ingrese la posicion x del centro de la figura: "<< endl;
    cin>>x;
    cout << "Ingrese la posicion y del centro de la figura: "<< endl;
    cin>>y;
    /*cout << "Ingrese el lado menor: "<< endl;
    cin>>ladomen;
    cout << "Ingrese el lado mayor: "<< endl;
    cin>>ladomay;*/
    /*cout << "Ingrese el radio menor: " << endl;
    cin>>radiomen;
    cout << "Ingrese el radio mayor: " << endl;
    cin >> radiomay;*/
    /*cout << "Ingrese el lado: " << endl;
    cin>>ladomen;
    ladomay=ladomen;*/
    cout << "Ingrese el radio: " << endl;
    cin >> radiomay;
    radiomen=radiomay;
    ClaseForma *bptr;
    //ClaseRectangulo *rectptr; //Rectangulo
    //ClaseRectangulo d(color,x,y,nombre,ladomen,ladomay);
    //ClaseElipse *eliptr; //Elipse
    //ClaseElipse e(color,x,y,nombre,radiomen,radiomay); 
    /*ClaseCuadrado *cuadrptr;
    ClaseCuadrado c(color,x,y,nombre,ladomen,ladomay);*/ //Cuadrado
    ClaseCirculo *circptr;
    ClaseCirculo cir(color,x,y,nombre,radiomen,radiomay);
    //bptr = &d; 
    //rectptr = &d; //Rectangulo
    //bptr = &e;
    //eliptr = &e; //Elipse
    //bptr = &c;
    //cuadrptr = &c; //Cuadrado
    bptr = &cir;
    circptr = &cir;
    bptr->imprimir();
    string _color;
    double _x,_y;
    cout << "Ingrese la nueva coordenada x: " << endl;
    cin>>_x;
    cout << "Ingrese la nueva coordenada y: " << endl;
    cin>>_y;
    bptr->mover(_x,_y);
    cout << "Ingrese el color al que desea cambiar: " << endl;
    cin>>_color;
    bptr->setcolor(_color);
    cout << "El nuevo color es: " << bptr->getcolor()<<endl;
    //rectptr->area(); 
    //rectptr->perimetro(); //Rectangulo0
    //eliptr->area(); // Elipse
    //cuadrptr->area(); 
    //cuadrptr->perimetro(); //Cuadrado
    circptr->area();
    circptr->perimetro();
    float f{0.0};
    cout << "Ingrese el factor de escala: " << endl;
    cin>>f;
    //rectptr->resize(f); //rectangulo
    //eliptr->resize(f);// elipse
    //cuadrptr->resize(f); //cuadrado
    //cout << "Rectangulo cambiado: " << endl; //rectangulo
    //rectptr->imprimir(); //rectangulo
    //cout << "Elipse cambiada: " << endl;// elipse
    //eliptr->imprimir(); //elipse
    //cout << "Cuadrado cambiado: " << endl; //cuadrado
    //cuadrptr->imprimir(); //cuadrado
    circptr->resize(f); //circulo
    cout << "Circulo cambiado: " << endl; //circulo
    circptr->imprimir(); //circulo
    system("pause");
    return 0;
}
