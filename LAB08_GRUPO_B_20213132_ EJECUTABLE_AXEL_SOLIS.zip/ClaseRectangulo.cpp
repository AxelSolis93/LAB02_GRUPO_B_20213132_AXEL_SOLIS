#include "stdafx.h" //Axel Jhuan Solis Zamata
#include "ClaseRectangulo.h"

ClaseRectangulo::ClaseRectangulo(string _color, double _x, double _y, string _nombre,float _ladomen, float _ladomay):ClaseForma(_color,_x,_y,_nombre){
    ladomen = _ladomen;
    ladomay = _ladomay;
}
ClaseRectangulo::~ClaseRectangulo(){

}
void ClaseRectangulo::imprimir(){
    ClaseForma::imprimir();
    cout << "Lado Mayor: " << ladomay<<endl;
    cout << "Lado Menor: " << ladomen<<endl;
}
void ClaseRectangulo::area(){
    cout << "El area es " << ladomay*ladomen << endl;
}
void ClaseRectangulo::perimetro(){
    cout << "El perimetro es " << (2*ladomen)+(2*ladomay) << endl;
}
void ClaseRectangulo::resize(float f){
    ladomen = ladomen*f;
    ladomay = ladomay*f;
}