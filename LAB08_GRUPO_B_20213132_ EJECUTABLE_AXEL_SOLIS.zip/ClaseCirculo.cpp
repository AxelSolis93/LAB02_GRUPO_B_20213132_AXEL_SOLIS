#include "stdafx.h" //Axel Jhuan Solis Zamata
#include "ClaseCirculo.h"
#include "ClaseElipse.h"
#include <cmath>
ClaseCirculo::ClaseCirculo(string _color, double _x, double _y, string _nombre,float _radiomen, float _radiomay):ClaseElipse(_color,_x,_y,_nombre,_radiomen,_radiomay){
}
ClaseCirculo::~ClaseCirculo(){
}
void ClaseCirculo::imprimir(){
    ClaseForma::imprimir();
    cout << "El radio es " << radiomay<<endl;
}
void ClaseCirculo::area(){
    cout << "El area es " << 2*(M_PI*radiomay) << endl;
}
void ClaseCirculo::perimetro(){
    cout << "El perimetro es " << M_PI*(radiomay*radiomay) << endl;
}
void ClaseCirculo::resize(float f){
    radiomay = radiomay*f;
    radiomen = radiomay;
}