#pragma once  //Axel Jhuan Solis Zamata
#include "ClaseForma.h"
class ClaseElipse : public ClaseForma{
    protected:
        float radiomen;
        float radiomay;
    public:
        ClaseElipse(string, double, double, string, float, float);
        ~ClaseElipse();
        void imprimir();
        void area();
        void resize(float);
};