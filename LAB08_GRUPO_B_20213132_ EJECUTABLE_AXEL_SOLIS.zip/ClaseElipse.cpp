#include "stdafx.h" //Axel Jhuan Solis Zamata
#include "ClaseElipse.h"
#include <cmath>
ClaseElipse::ClaseElipse(string _color, double _x, double _y, string _nombre,float _radiomen, float _radiomay):ClaseForma(_color,_x,_y,_nombre){
    radiomen = _radiomen;
    radiomay = _radiomay;
}
ClaseElipse::~ClaseElipse(){

}
void ClaseElipse::imprimir(){
    ClaseForma::imprimir();
    cout << "Radio Mayor: " << radiomay<<endl;
    cout << "Radio Menor: " << radiomen<<endl;
}
void ClaseElipse::area(){
    cout << "El area es " << M_PI*(radiomay*radiomen) << endl;
}
void ClaseElipse::resize(float f){
    radiomen = radiomen*f;
    radiomay = radiomay*f;
}