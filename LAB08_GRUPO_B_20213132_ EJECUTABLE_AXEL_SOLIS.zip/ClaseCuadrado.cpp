#include "stdafx.h" //Axel Jhuan Solis Zamata
#include "ClaseCuadrado.h"
#include "ClaseRectangulo.h"

ClaseCuadrado::ClaseCuadrado(string _color, double _x, double _y, string _nombre,float _ladomen, float _ladomay):ClaseRectangulo(_color,_x,_y,_nombre,_ladomen,_ladomay){
}
ClaseCuadrado::~ClaseCuadrado(){
}
void ClaseCuadrado::imprimir(){
    ClaseRectangulo::imprimir();
}
void ClaseCuadrado::area(){
    cout << "El area es " << ladomay*ladomay << endl;
}
void ClaseCuadrado::perimetro(){
    cout << "El perimetro es " << 4*ladomen << endl;
}
void ClaseCuadrado::resize(float f){
    ladomen = ladomen*f;
    ladomay = ladomen;
}