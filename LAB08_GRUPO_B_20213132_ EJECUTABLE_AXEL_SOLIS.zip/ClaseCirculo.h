#pragma once  //Axel Jhuan Solis Zamata
#include "ClaseElipse.h"
class ClaseCirculo : public ClaseElipse{
    public:
        ClaseCirculo(string, double, double, string,float,float);
        ~ClaseCirculo();
        void imprimir();
        void area();
        void perimetro();
        void resize(float);
};