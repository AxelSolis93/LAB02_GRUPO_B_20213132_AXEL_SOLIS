#include <iostream>
using namespace std;
int main()
{
	string nombre,apellidoP,apellidoM; //Axel Jhuan Solis Zamata
	cout << "Ingrese su primer nombre: " << endl;
	cin >> nombre;
	cout << "Ingrese su apellido paterno: " << endl;
	cin >> apellidoP;
	cout << "Ingrese su apellido materno: " << endl;
	cin >> apellidoM;
	cout << "Su correo institucional es: "<< nombre[0] << apellidoP << apellidoM[0] << "@unsa.edu.pe" << endl;
	cout << endl << endl;
	system("pause");
}
