#include <iostream>
using namespace std;
int main()
{
	float a;
	cout << "Ingrese un numero flotante: " << endl;
	cin >> a;
	cout << "El numero redondeado es: " << int(a) << endl;
	cout << endl << endl;
	system("pause");
}//Axel Jhuan Solis Zamata
