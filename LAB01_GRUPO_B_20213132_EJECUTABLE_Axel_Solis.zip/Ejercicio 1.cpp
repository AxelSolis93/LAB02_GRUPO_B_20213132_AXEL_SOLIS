#include <iostream> //Axel Jhuan Solis Zamata
using namespace std;
int main()
{
	int a,b;
	cout << "Ingrese el primer numero entero: " << endl;
	cin >> a;
	cout << "Ingrese el segundo numero entero: " << endl;
	cin >> b;
	cout << "El producto de ambos numeros es: " << a*b << endl;
	cout << endl << endl;
	system("pause");
}
