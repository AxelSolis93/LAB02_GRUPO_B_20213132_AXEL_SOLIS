#include <iostream>
using namespace std;
int main()
{
	int a,b;
	cout << "Ingrese el primer numero entero: " << endl;
	cin >> a;
	cout << "Ingrese el segundo numero entero: " << endl;
	cin >> b;
	if(a%b==0||b%a==0){
		cout << "Ambos numeros son divisibles entre si" << endl;
	}else{
		cout << a << " y " << b << " no son divisibles entre si" << endl;
	}
	cout << endl << endl;
	system("pause");
} //Axel Jhuan Solis Zamata
