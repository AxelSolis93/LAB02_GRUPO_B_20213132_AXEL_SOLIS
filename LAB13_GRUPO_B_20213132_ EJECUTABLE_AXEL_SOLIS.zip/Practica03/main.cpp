#include <iostream>//Axel Jhuan Solis Zamata
#include <string>
#include <vector>
using namespace std;

struct jugador{
    string nombre;
    int edad;
    float talla;
};

int main(){
    jugador Jugadores[10];
    for(int i=0;i<10;i++){
        cout << "Ingrese el nombre del jugador numero " <<i+1 << endl;
        cin>>Jugadores[i].nombre;
        cout << "Ingrese su edad: " << endl;
        cin>>Jugadores[i].edad;
        cout << "Ingrese su talla: " << endl;
        cin>>Jugadores[i].talla;
    }
    for(int i=0;i<10;i++){
        if(Jugadores[i].edad<20&&Jugadores[i].edad>1.70){
            cout << Jugadores[i].nombre << " tiene menos de 20 años y una altura mayor a 1.70" << endl;
        }
    }
    system("pause");
    return 0;
}
