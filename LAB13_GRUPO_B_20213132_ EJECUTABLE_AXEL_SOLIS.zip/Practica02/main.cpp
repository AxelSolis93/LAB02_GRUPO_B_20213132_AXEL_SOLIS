#include <iostream>//Axel Jhuan Solis Zamata
#include <string>
using namespace std;

struct estudiante{
    string nombre;
    char grupo;
    float n1;
    float n2;
    float n3;
    float pf;
};

int main(){
    int n{0};
    float prom{0.0};
    cout << "Ingrese el numero de alumnos" << endl;
    cin>>n;
    estudiante alum[n];
    for(int i=0;i<n;i++){
        cout << "Ingrese el nombre del alumno numero " <<i+1 << endl;
        cin>>alum[i].nombre;
        cout << "Ingrese su grupo: " << endl;
        cin>>alum[i].grupo;
        cout << "Ingrese la primera nota: " << endl;
        cin>>alum[i].n1;
        cout << "Ingrese la segunda nota: " << endl;
        cin>>alum[i].n2;
        cout << "Ingrese la tercera nota: " << endl;
        cin>>alum[i].n3;
        cout << "Ingrese la nota del proyecto final: " << endl;
        cin>>alum[i].pf;
    }
    for(int i=0;i<n;i++){
        prom = (((alum[i].n1)*0.15)+((alum[i].n1)*0.2)+((alum[i].n1)*0.25)+((alum[i].n1)*0.4));
        if(prom>10.5){
            cout << alum[i].nombre << " aprobo" << endl;
        }
    }
    system("pause");
    return 0;
}
