#include <iostream>//Axel Jhuan Solis Zamata
#include <string>
#include <vector>
using namespace std;

struct empleado{
    string nombre;
    string sexo;
    float sueldo;
};

int main(){
    string op{"si"},nombre{" "},sexo{" "};
    float sueldo{0.0};
    vector<empleado> Empleados; 
    while(op=="si"){
        cout << "Ingrese el nombre del empleado: " << endl;
        cin>>nombre;
        cout << "Ingrese su sexo: " << endl;
        cin>>sexo;
        cout << "Ingrese su sueldo: " << endl;
        cin>>sueldo;
        Empleados.push_back(empleado({nombre,sexo,sueldo}));//Crea el empleado
        cout << "Desea agregar otro empleado?(si/no): " << endl;
        cin>>op;
    }
    int men=Empleados.at(0).sueldo,may=men,pmen{0},pmay{0};
    for(int i=0;i<Empleados.size();i++){
        if(Empleados.at(i).sueldo<men){
            men = Empleados.at(i).sueldo;
            pmen=i;
        }else if(Empleados.at(i).sueldo>may){
            may = Empleados.at(i).sueldo;
            pmay=i;
        }
    }
    cout << "La persona con el menor sueldo es " << Empleados.at(pmen).nombre << ", de sexo " << Empleados.at(pmen).sexo << " y con sueldo de " << Empleados.at(pmen).sueldo << endl;
    cout << "La persona con el mayor sueldo es " << Empleados.at(pmay).nombre << ", de sexo " << Empleados.at(pmay).sexo << " y con sueldo de " << Empleados.at(pmay).sueldo << endl;
    
    
    system("pause");
    return 0;
}
