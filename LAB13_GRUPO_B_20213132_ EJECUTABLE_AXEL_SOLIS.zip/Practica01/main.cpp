#include <iostream>//Axel Jhuan Solis Zamata
#include <string>
using namespace std;

struct fecha{
    int dia;
    int mes;
    int año;
} f0;

struct persona{
    string nombre;
    fecha cump;
} p1;


int main(){
    int n{0},ma{0};
    cout << "Ingrese el numero de personas" << endl;
    cin>>n;
    persona cumple[n];
    for(int i=0;i<n;i++){
        cout << "Ingrese el nombre de la persona numero " <<i+1 << endl;
        cin>>cumple[i].nombre;
        cout << "Ingrese el dia de su cumpleaños" << endl;
        cin>>cumple[i].cump.dia;
        cout << "Ingrese el mes de su cumpleaños" << endl;
        cin>>cumple[i].cump.mes;
        cout << "Ingrese el año de su cumpleaños" << endl;
        cin>>cumple[i].cump.año;
    }
    cout << "Ingrese el mes actual: " <<endl;
    cin>>ma;
    for(int i=0;i<n;i++){
        if(ma==cumple[i].cump.mes){
            cout << cumple[i].nombre << " cumple este mes" << endl;
        }
    }
    system("pause");
    return 0;
}
