#include <iostream>//Axel Jhuan Solis Zamata
#include "Pila.h"
using namespace std;
int main(){
    bool cond{false};
    Pila<int> P; //Inicia la pila
    while(cond==false){
        int e{0};
        cout << "1. Ingresar un numero    2. Mostrar la pila   3. Salir"<<endl;
        cin>>e;
        switch(e){
            case 1:int x;cout<<"Ingrese el numero: "<<endl;cin>>x;P.Push(x);break;
            case 2:P.print();break;
            case 3:cond=true;break;
            default: cout << "Opcion invalida" << endl;
        }
    }
    system("pause");
    return 0;
}
