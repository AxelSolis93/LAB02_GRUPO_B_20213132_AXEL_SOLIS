//Axel Jhuan Solis Zamata
#include "nodo.h"
using namespace std;
template <class T>
class Pila{
    private:
        Nodo<T>* extremo;
    public:
        Pila(){
            extremo = NULL;   
        }
        void Push(T x){   
            if(extremo==nullptr){   
                extremo = new Nodo<T>;
                extremo->sgte = nullptr;
                extremo->datos=x;
            }else{
                Nodo<T>* aux = new Nodo<T>;
                aux->datos = x;
                aux->sgte = extremo;
                extremo = aux; 
            }
        }
        //Futura funcion
        void print(){   
            bool stop{false};
            Nodo<T>* aux = extremo;
            if(extremo==nullptr){
                cout << "La lista esta vacia" << endl;
                return;
            }
            while(stop==false){
                cout << aux->datos << " ";
                if(aux->sgte==nullptr){
                    stop=true;
                }
                aux = aux->sgte;
            }
            cout <<endl;
        }
};


