//Axel Jhuan Solis Zamata
#include "nodo.h"
using namespace std;
template <class T>
class Pila{
    private:
        Nodo<T>* extremo;
    public:
        Pila(){
            extremo = NULL;   
        }
        void Push(T x){   
            if(extremo==nullptr){   
                extremo = new Nodo<T>;
                extremo->sgte = nullptr;
                extremo->datos=x;
            }else{
                Nodo<T>* aux = new Nodo<T>;
                aux->datos = x;
                aux->sgte = extremo;
                extremo = aux; 
            }
        }
        void Pop(){   
            if(extremo==nullptr){   
                cout << "La pila esta vacia"<<endl;
            }else{
                Nodo<T>* aux = extremo;
                extremo=extremo->sgte;
                delete aux; 
            }
        }
        int search(T x){
            int lugar{0};//posicion en la pila
            bool stop{false};
            Nodo<T>* aux = extremo;
            if(extremo==nullptr){
                cout << "La pila esta vacia, por lo tanto, ";
                return 0;
            }
            while(stop==false){
                lugar++;
                if(aux->datos==x){
                    return lugar;
                }else if(aux->sgte==nullptr){
                    stop=true;
                }
                aux = aux->sgte;
            }
            lugar=0;//No encontro x por lo que vuelve a 0
            return lugar;
        }
        void print(){   
            bool stop{false};
            Nodo<T>* aux = extremo;
            if(extremo==nullptr){
                cout << "La pila esta vacia" << endl;
                return;
            }
            while(stop==false){
                cout << aux->datos << " ";
                if(aux->sgte==nullptr){
                    stop=true;
                }
                aux = aux->sgte;
            }
            cout <<endl;
        }
};


